/**
 * ==============================================================================
 * Process Development Monthly Report Automation System
 * Module: Google Sheets Cloud Synchronization Service
 * Organization: WALTON Hi-Tech Industries PLC
 * ==============================================================================
 */

const GoogleSheetsSync = {
  STORAGE_KEY_URL: 'walton_gas_webapp_url',
  STORAGE_KEY_LAST_SYNC: 'walton_gas_last_sync_timestamp',
  STORAGE_KEY_QUEUE: 'walton_gas_sync_pending_queue',
  
  status: 'OFFLINE', // 'CONNECTED' | 'SYNCING' | 'OFFLINE' | 'ERROR'
  lastSyncTime: null,
  isSyncing: false,
  initialSyncCompleted: false,
  _viewsHydratedOnce: false,
  subscribers: [],
  broadcastChannel: null,
  _listenersAttached: false,
  _consecutiveFailures: 0,
  _lastFailureTime: 0,

  /**
   * Helper: fetch with strict timeout using AbortController
   */
  async _fetchWithTimeout(url, options = {}, timeoutMs = 10000) {
    if (typeof AbortController === 'undefined') {
      return fetch(url, options);
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    try {
      return await fetch(url, { ...options, signal: controller.signal });
    } finally {
      clearTimeout(timeoutId);
    }
  },

  /**
   * Helper: safely parses JSON and detects Google Drive HTML throttling/error pages
   */
  async _safeJson(response) {
    if (!response || !response.ok) return null;
    try {
      const text = await response.text();
      if (!text || text.trim().startsWith('<') || text.includes('<!DOCTYPE') || text.includes('<html')) {
        console.warn("Google Apps Script temporarily rate limited or busy. Waiting for next cycle.");
        return null;
      }
      return JSON.parse(text);
    } catch (e) {
      console.warn("Safe JSON parse error:", e.message);
      return null;
    }
  },

  /**
   * Initialize service
   */
  init() {
    this.lastSyncTime = localStorage.getItem(this.STORAGE_KEY_LAST_SYNC) || null;
    const url = this.getWebAppUrl();
    if (url) {
      this.status = 'SYNCING';
      this._updateNavbarBadge();

      // Immediate pull on startup after initial render settles
      setTimeout(async () => {
        await this.flushPendingQueue();
        const success = await this.pullFromCloud(true);
        if (!success && !this.initialSyncCompleted) {
          setTimeout(() => {
            this.pullFromCloud(true);
          }, 2500);
        }
      }, 400);

      // Safe background polling every 15 seconds, only when tab is actively visible
      setInterval(() => {
        if (!this.isSyncing && this.getWebAppUrl()) {
          if (typeof document !== 'undefined' && document.visibilityState === 'hidden') {
            return; // Skip background polling when user is not viewing this tab
          }
          // If backed off due to temporary Google rate limiting, wait 35 seconds
          if (this._consecutiveFailures >= 2 && (Date.now() - this._lastFailureTime < 35000)) {
            return;
          }
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      }, 15000);
    } else {
      this.status = 'OFFLINE';
      this._updateNavbarBadge();
    }

    // Set up BroadcastChannel for zero-latency sync between multiple open tabs/windows
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window && !this.broadcastChannel) {
      try {
        this.broadcastChannel = new BroadcastChannel('walton_report_sync');
        this.broadcastChannel.onmessage = (event) => {
          if (event && event.data && event.data.type === 'SYNC_UPDATE') {
            if (window.appState && window.appState.workbookMgr) {
              window.appState.workbookMgr.load();
              this._refreshActiveViews();
            }
          }
        };
      } catch (e) {
        console.warn("BroadcastChannel notice:", e);
      }
    }

    // Attach real-time wakeup listeners on window focus, visibilitychange, pageshow, and online state
    if (!this._listenersAttached && typeof window !== 'undefined') {
      window.addEventListener('focus', () => {
        if (this.getWebAppUrl() && !this.isSyncing) {
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && this.getWebAppUrl() && !this.isSyncing) {
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      window.addEventListener('pageshow', () => {
        if (this.getWebAppUrl() && !this.isSyncing) {
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      window.addEventListener('online', () => {
        if (this.getWebAppUrl()) {
          this.status = 'CONNECTED';
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      this._listenersAttached = true;
    }

    this._notifySubscribers();
  },

  _broadcastUpdate(reason) {
    if (this.broadcastChannel) {
      try {
        this.broadcastChannel.postMessage({ type: 'SYNC_UPDATE', reason, timestamp: Date.now() });
      } catch (e) {}
    }
  },

  getPendingQueue() {
    try {
      const q = localStorage.getItem(this.STORAGE_KEY_QUEUE);
      return q ? JSON.parse(q) : [];
    } catch (e) {
      return [];
    }
  },

  savePendingQueue(q) {
    try {
      localStorage.setItem(this.STORAGE_KEY_QUEUE, JSON.stringify(q || []));
    } catch (e) {
      console.warn("Storage notice:", e);
    }
  },

  queuePending(actionItem) {
    const q = this.getPendingQueue();
    q.push({ ...actionItem, queued_at: new Date().toISOString() });
    this.savePendingQueue(q);
  },

  async flushPendingQueue() {
    const q = this.getPendingQueue();
    if (!q || q.length === 0) return;

    const url = this.getWebAppUrl();
    if (!url) return;

    const remaining = [];
    for (const item of q) {
      try {
        await fetch(url, {
          method: 'POST',
          mode: 'cors',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(item)
        });
      } catch (err) {
        remaining.push(item);
      }
    }
    this.savePendingQueue(remaining);
  },

  /**
   * Get configured Web App URL (local override or config default)
   */
  getWebAppUrl() {
    const local = localStorage.getItem(this.STORAGE_KEY_URL);
    if (local && local.trim()) return local.trim();
    if (typeof APP_CONFIG !== 'undefined' && APP_CONFIG.GOOGLE_WORKSPACE && APP_CONFIG.GOOGLE_WORKSPACE.APPS_SCRIPT_WEBAPP_URL) {
      return APP_CONFIG.GOOGLE_WORKSPACE.APPS_SCRIPT_WEBAPP_URL.trim();
    }
    return "";
  },

  /**
   * Save Web App URL
   */
  setWebAppUrl(url) {
    const clean = (url || "").trim();
    if (clean) {
      localStorage.setItem(this.STORAGE_KEY_URL, clean);
      this.status = 'CONNECTED';
      this.flushPendingQueue();
      this.pullFromCloud(true);
    } else {
      localStorage.removeItem(this.STORAGE_KEY_URL);
      this.status = 'OFFLINE';
    }
    this._notifySubscribers();
  },

  /**
   * Subscribe to sync state changes
   */
  onStateChange(callback) {
    if (typeof callback === 'function') {
      this.subscribers.push(callback);
      callback(this.getStatus());
    }
  },

  _notifySubscribers() {
    const s = this.getStatus();
    this.subscribers.forEach(cb => {
      try { cb(s); } catch (e) { console.warn("Sync subscriber notice:", e); }
    });
    this._updateNavbarBadge();
  },

  getStatus() {
    return {
      status: this.status,
      isSyncing: this.isSyncing,
      lastSyncTime: this.lastSyncTime,
      urlConfigured: !!this.getWebAppUrl()
    };
  },

  /**
   * Test connection to Google Apps Script Web App
   */
  async testConnection(customUrl = null) {
    const url = (customUrl || this.getWebAppUrl()).trim();
    if (!url) {
      throw new Error("No Google Apps Script Web App URL provided.");
    }

    const testEndpoint = url + (url.includes('?') ? '&' : '?') + 'action=PING&_t=' + Date.now();
    const response = await fetch(testEndpoint, {
      method: 'GET',
      mode: 'cors'
    });

    if (!response.ok) {
      throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    if (data && data.status === 'OK') {
      return data;
    } else {
      throw new Error(data.message || "Invalid response from Apps Script endpoint.");
    }
  },

  /**
   * Push a single task to Google Sheets in background
   */
  async pushTask(task) {
    const url = this.getWebAppUrl();
    if (!url || !task || !task.task_id) return false;

    task.last_updated = task.last_updated || new Date().toISOString();

    try {
      // Using text/plain prevents CORS OPTIONS preflight
      await this._fetchWithTimeout(url, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          action: 'SYNC_TASK',
          payload: task
        })
      }, 10000);
      this.lastSyncTime = new Date().toISOString();
      localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
      this.status = 'CONNECTED';
      this._broadcastUpdate('TASK_PUSHED');
      // Trigger immediate background sync so concurrent updates from other laptops merge
      setTimeout(() => {
        if (!this.isSyncing) this.pullFromCloud(true);
      }, 600);
      return true;
    } catch (e) {
      console.warn("Background cloud task sync notice - enqueuing retry:", e);
      this.queuePending({ action: 'SYNC_TASK', payload: task });
      return false;
    }
  },

  /**
   * Delete a single task from Google Sheets in background
   */
  async deleteTask(taskId, month) {
    const url = this.getWebAppUrl();
    if (!url || !taskId) return false;

    try {
      await this._fetchWithTimeout(url, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          action: 'DELETE_TASK',
          payload: { task_id: taskId, month: month }
        })
      }, 10000);
      this.lastSyncTime = new Date().toISOString();
      localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
      this.status = 'CONNECTED';
      this._broadcastUpdate('TASK_DELETED');
      return true;
    } catch (e) {
      console.warn("Cloud delete notice - enqueuing retry:", e);
      this.queuePending({ action: 'DELETE_TASK', payload: { task_id: taskId, month: month } });
      return false;
    }
  },

  /**
   * Pull all tasks and cost savings from Google Sheets
   */
  async pullFromCloud(silent = false) {
    const url = this.getWebAppUrl();
    if (!url) return false;
    if (this.isSyncing) return false; // Prevent overlapping pulls

    try {
      this.isSyncing = true;
      this._updateNavbarBadge();

      const activeMonth = (window.appState && window.appState.workbookMgr && window.appState.workbookMgr.activeMonth)
        ? window.appState.workbookMgr.activeMonth
        : 'SEP-2026';

      let data = null;

      // TIER 1: Try fast month-specific fetch (8s timeout, ~3 KB payload)
      try {
        const monthEndpoint = url + (url.includes('?') ? '&' : '?') + 'action=GET_MONTH&month=' + encodeURIComponent(activeMonth) + '&_t=' + Date.now();
        const resMonth = await this._fetchWithTimeout(monthEndpoint, { method: 'GET', mode: 'cors' }, 8000);
        const monthData = await this._safeJson(resMonth);
        if (monthData && monthData.status === 'OK' && Array.isArray(monthData.tasks) && monthData.tasks.length > 0) {
          data = {
            status: 'OK',
            workbooks: {
              [activeMonth]: monthData.tasks
            }
          };
        }
      } catch (monthErr) {
        // Fallback to Tier 2
      }

      // TIER 2: Fast recent tasks fetch (< 100ms, ~5 KB payload)
      if (!data) {
        try {
          const recentEndpoint = url + (url.includes('?') ? '&' : '?') + 'action=GET_RECENT&limit=80&_t=' + Date.now();
          const resRecent = await this._fetchWithTimeout(recentEndpoint, { method: 'GET', mode: 'cors' }, 8000);
          const recentData = await this._safeJson(resRecent);
          if (recentData && recentData.status === 'OK' && Array.isArray(recentData.tasks) && recentData.tasks.length > 0) {
            const grouped = {};
            recentData.tasks.forEach(t => {
              const m = (window.appState && window.appState.workbookMgr)
                ? window.appState.workbookMgr.normalizeMonth(t.month || activeMonth)
                : (t.month || activeMonth);
              if (!grouped[m]) grouped[m] = [];
              grouped[m].push(t);
            });
            data = {
              status: 'OK',
              workbooks: grouped
            };
          }
        } catch (recentErr) {
          // Fallback to Tier 3
        }
      }

      // TIER 3: Full history fallback ONLY if Tier 1 & 2 returned 0 (e.g. initial boot or explicit manual sync)
      if (!data && (!this.initialSyncCompleted || !silent)) {
        const fullEndpoint = url + (url.includes('?') ? '&' : '?') + 'action=GET_ALL&_t=' + Date.now();
        const resFull = await this._fetchWithTimeout(fullEndpoint, { method: 'GET', mode: 'cors' }, 30000);
        data = await this._safeJson(resFull);
      }

      if (data && data.status === 'OK') {
        this._consecutiveFailures = 0;
        let changed = false;

        // Merge workbooks into MonthWorkbookManager
        if (data.workbooks && window.appState && window.appState.workbookMgr) {
          changed = window.appState.workbookMgr.mergeFromCloud(data.workbooks) || changed;
        }

        this.lastSyncTime = new Date().toISOString();
        localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
        this.status = 'CONNECTED';
        this.initialSyncCompleted = true;

        // Refresh views if data changed or on initial hydration
        if (changed || !this._viewsHydratedOnce) {
          this._viewsHydratedOnce = true;
          this._refreshActiveViews();
          this._broadcastUpdate('DATA_MERGED');
        }

        if (!silent && typeof HELPERS !== 'undefined' && HELPERS.showToast) {
          HELPERS.showToast("Cloud sync complete: All tasks up-to-date.", "success");
        }
        return true;
      } else {
        // Record failure for adaptive backoff
        this._consecutiveFailures = (this._consecutiveFailures || 0) + 1;
        this._lastFailureTime = Date.now();
      }
    } catch (err) {
      console.warn("Pull from cloud notice:", err);
      this._consecutiveFailures = (this._consecutiveFailures || 0) + 1;
      this._lastFailureTime = Date.now();
      this.status = 'CONNECTED';
      if (!silent && typeof HELPERS !== 'undefined' && HELPERS.showToast) {
        HELPERS.showToast("Cloud sync notice: " + err.message, "info");
      }
      return false;
    } finally {
      this.isSyncing = false;
      this._updateNavbarBadge();
      this._notifySubscribers();
    }
  },

  /**
   * One-Click Data Optimization: Archive Jan-Aug historical tasks to ARCHIVE_TASKS sheet
   */
  async archiveOldData() {
    const url = this.getWebAppUrl();
    if (!url) throw new Error("Please configure Google Apps Script URL first.");

    this.isSyncing = true;
    this._updateNavbarBadge();

    try {
      const endpoint = url + (url.includes('?') ? '&' : '?') + 'action=ARCHIVE_OLD_DATA&_t=' + Date.now();
      const res = await this._fetchWithTimeout(endpoint, { method: 'GET', mode: 'cors' }, 35000);
      const data = await this._safeJson(res);
      if (data && data.status === 'OK') {
        this.initialSyncCompleted = false;
        await this.pullFromCloud(true);
        return data;
      }
      throw new Error((data && data.message) ? data.message : "Archive request failed.");
    } finally {
      this.isSyncing = false;
      this._updateNavbarBadge();
      this._notifySubscribers();
    }
  },

  /**
   * Push all current local data to Google Sheet
   */
  async pushAllLocalData() {
    const url = this.getWebAppUrl();
    if (!url) throw new Error("Please configure Google Apps Script Web App URL first.");

    if (!window.appState || !window.appState.workbookMgr) {
      throw new Error("System state not initialized.");
    }

    this.isSyncing = true;

    try {
      const workbooks = window.appState.workbookMgr.workbooks || {};
      let costSavings = [];
      if (typeof CostSavingTracker !== 'undefined' && CostSavingTracker.getAllRecords) {
        costSavings = CostSavingTracker.getAllRecords();
      }

      const res = await this._fetchWithTimeout(url, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          action: 'BULK_PUSH',
          payload: {
            workbooks: workbooks,
            cost_savings: costSavings
          }
        })
      }, 30000);

      if (!res.ok) throw new Error("Upload failed: " + res.status);
      const data = await res.json();
      if (data.status === 'OK') {
        this.lastSyncTime = new Date().toISOString();
        localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
        this.status = 'CONNECTED';
        this._broadcastUpdate('BULK_PUSHED');
        return data;
      } else {
        throw new Error(data.message || "Bulk push error.");
      }
    } finally {
      this.isSyncing = false;
      this._notifySubscribers();
    }
  },

  _setStatus(s) {
    this.status = s;
    this._notifySubscribers();
  },

  _refreshActiveViews() {
    try {
      const activeEl = document.activeElement;
      const isUserTyping = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');

      if (window.appState && window.appState.activeTab === 'monthly-input' && window.appState.monthlyInputView) {
        if (!isUserTyping) {
          window.appState.monthlyInputView.render();
        } else {
          // Re-render safely when user finishes typing
          activeEl.addEventListener('blur', () => {
            if (window.appState && window.appState.activeTab === 'monthly-input') {
              window.appState.monthlyInputView.render();
            }
          }, { once: true });
        }
      }

      if (window.appState && window.appState.activeTab === 'projects' && window.appState.projectsView) {
        if (!isUserTyping) {
          window.appState.projectsView.render();
        }
      }

      if (window.appState && window.appState.activeTab === 'dashboard' && window.appState.dashboardView) {
        window.appState.dashboardView.render();
      }
    } catch (e) {
      console.warn("View refresh notice:", e);
    }
  },

  _updateNavbarBadge() {
    const badge = document.getElementById('navbar-cloud-sync-badge');
    if (!badge) return;

    if (this.status === 'SYNCING' || (this.isSyncing && !this.initialSyncCompleted)) {
      badge.innerHTML = `
        <button onclick="GoogleSheetsSync.pullFromCloud(false)" title="Connecting and syncing with Google Sheets..." 
                class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-amber-500/10 text-amber-700 border border-amber-500/20 transition-colors">
          <span class="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
          <span>Syncing...</span>
        </button>
      `;
    } else if (this.status === 'CONNECTED') {
      badge.innerHTML = `
        <button onclick="GoogleSheetsSync.pullFromCloud(false)" title="Cloud Sync Active (Google Sheets). Click to refresh." 
                class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors">
          <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span>Cloud Synced</span>
        </button>
      `;
    } else if (this.status === 'OFFLINE') {
      badge.innerHTML = `
        <button onclick="if(window.appState) window.appState.switchTab('settings')" title="Click to connect Google Sheets" 
                class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 text-slate-500 border border-slate-200 hover:text-slate-700 transition-colors">
          <span class="w-2 h-2 rounded-full bg-slate-400"></span>
          <span>Offline</span>
        </button>
      `;
    } else {
      badge.innerHTML = '';
    }
  }
};

if (typeof window !== 'undefined') {
  window.GoogleSheetsSync = GoogleSheetsSync;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = GoogleSheetsSync;
}