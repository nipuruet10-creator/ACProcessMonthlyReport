﻿/**
 * ==============================================================================
 * Process Development Monthly Report Automation System
 * Module: Google Sheets Cloud Synchronization Service
 * Organization: WALTON Hi-Tech Industries PLC
 * ==============================================================================
 */

const GoogleSheetsSync = {
  STORAGE_KEY_URL: 'walton_gas_webapp_url',
  STORAGE_KEY_LAST_SYNC: 'walton_gas_last_sync_timestamp',
  STORAGE_KEY_QUEUE: 'walton_gas_sync_pending_queue',
  
  status: 'OFFLINE', // 'CONNECTED' | 'SYNCING' | 'OFFLINE' | 'ERROR'
  lastSyncTime: null,
  isSyncing: false,
  subscribers: [],
  broadcastChannel: null,
  _listenersAttached: false,

  /**
   * Initialize service
   */
  init() {
    this.lastSyncTime = localStorage.getItem(this.STORAGE_KEY_LAST_SYNC) || null;
    const url = this.getWebAppUrl();
    if (url) {
      this.status = 'CONNECTED';
      // Automatically pull latest data on startup and flush any pending queue
      setTimeout(() => {
        this.flushPendingQueue();
        this.pullFromCloud(true);
      }, 500);

      // Rapid background refresh (every 5 seconds) for real-time collaboration across devices
      setInterval(() => {
        if (this.status === 'CONNECTED' && !this.isSyncing) {
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      }, 5000);
    } else {
      this.status = 'OFFLINE';
    }

    // Set up BroadcastChannel for zero-latency sync between multiple open tabs/windows
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window && !this.broadcastChannel) {
      try {
        this.broadcastChannel = new BroadcastChannel('walton_report_sync');
        this.broadcastChannel.onmessage = (event) => {
          if (event && event.data && event.data.type === 'SYNC_UPDATE') {
            if (window.appState && window.appState.workbookMgr) {
              window.appState.workbookMgr.load();
              this._refreshActiveViews();
            }
          }
        };
      } catch (e) {
        console.warn("BroadcastChannel notice:", e);
      }
    }

    // Attach real-time wakeup listeners on window focus, visibilitychange, pageshow, and online state
    if (!this._listenersAttached && typeof window !== 'undefined') {
      window.addEventListener('focus', () => {
        if (this.getWebAppUrl() && !this.isSyncing) {
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible' && this.getWebAppUrl() && !this.isSyncing) {
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      window.addEventListener('pageshow', () => {
        if (this.getWebAppUrl() && !this.isSyncing) {
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      window.addEventListener('online', () => {
        if (this.getWebAppUrl()) {
          this.status = 'CONNECTED';
          this.flushPendingQueue();
          this.pullFromCloud(true);
        }
      });

      this._listenersAttached = true;
    }

    this._notifySubscribers();
  },

  _broadcastUpdate(reason) {
    if (this.broadcastChannel) {
      try {
        this.broadcastChannel.postMessage({ type: 'SYNC_UPDATE', reason, timestamp: Date.now() });
      } catch (e) {}
    }
  },

  getPendingQueue() {
    try {
      const q = localStorage.getItem(this.STORAGE_KEY_QUEUE);
      return q ? JSON.parse(q) : [];
    } catch (e) {
      return [];
    }
  },

  savePendingQueue(q) {
    try {
      localStorage.setItem(this.STORAGE_KEY_QUEUE, JSON.stringify(q || []));
    } catch (e) {
      console.warn("Storage notice:", e);
    }
  },

  queuePending(actionItem) {
    const q = this.getPendingQueue();
    q.push({ ...actionItem, queued_at: new Date().toISOString() });
    this.savePendingQueue(q);
  },

  async flushPendingQueue() {
    const q = this.getPendingQueue();
    if (!q || q.length === 0) return;

    const url = this.getWebAppUrl();
    if (!url) return;

    const remaining = [];
    for (const item of q) {
      try {
        await fetch(url, {
          method: 'POST',
          mode: 'cors',
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify(item)
        });
      } catch (err) {
        remaining.push(item);
      }
    }
    this.savePendingQueue(remaining);
  },

  /**
   * Get configured Web App URL (local override or config default)
   */
  getWebAppUrl() {
    const local = localStorage.getItem(this.STORAGE_KEY_URL);
    if (local && local.trim()) return local.trim();
    if (typeof APP_CONFIG !== 'undefined' && APP_CONFIG.GOOGLE_WORKSPACE && APP_CONFIG.GOOGLE_WORKSPACE.APPS_SCRIPT_WEBAPP_URL) {
      return APP_CONFIG.GOOGLE_WORKSPACE.APPS_SCRIPT_WEBAPP_URL.trim();
    }
    return "";
  },

  /**
   * Save Web App URL
   */
  setWebAppUrl(url) {
    const clean = (url || "").trim();
    if (clean) {
      localStorage.setItem(this.STORAGE_KEY_URL, clean);
      this.status = 'CONNECTED';
      this.flushPendingQueue();
      this.pullFromCloud(true);
    } else {
      localStorage.removeItem(this.STORAGE_KEY_URL);
      this.status = 'OFFLINE';
    }
    this._notifySubscribers();
  },

  /**
   * Subscribe to sync state changes
   */
  onStateChange(callback) {
    if (typeof callback === 'function') {
      this.subscribers.push(callback);
      callback(this.getStatus());
    }
  },

  _notifySubscribers() {
    const s = this.getStatus();
    this.subscribers.forEach(cb => {
      try { cb(s); } catch (e) { console.warn("Sync subscriber notice:", e); }
    });
    this._updateNavbarBadge();
  },

  getStatus() {
    return {
      status: this.status,
      isSyncing: this.isSyncing,
      lastSyncTime: this.lastSyncTime,
      urlConfigured: !!this.getWebAppUrl()
    };
  },

  /**
   * Test connection to Google Apps Script Web App
   */
  async testConnection(customUrl = null) {
    const url = (customUrl || this.getWebAppUrl()).trim();
    if (!url) {
      throw new Error("No Google Apps Script Web App URL provided.");
    }

    const testEndpoint = url + (url.includes('?') ? '&' : '?') + 'action=PING&_t=' + Date.now();
    const response = await fetch(testEndpoint, {
      method: 'GET',
      mode: 'cors'
    });

    if (!response.ok) {
      throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    if (data && data.status === 'OK') {
      return data;
    } else {
      throw new Error(data.message || "Invalid response from Apps Script endpoint.");
    }
  },

  /**
   * Push a single task to Google Sheets in background
   */
  async pushTask(task) {
    const url = this.getWebAppUrl();
    if (!url || !task || !task.task_id) return false;

    task.last_updated = task.last_updated || new Date().toISOString();

    try {
      this._setStatus('SYNCING');
      // Using text/plain prevents CORS OPTIONS preflight
      await fetch(url, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          action: 'SYNC_TASK',
          payload: task
        })
      });
      this.lastSyncTime = new Date().toISOString();
      localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
      this._setStatus('CONNECTED');
      this._broadcastUpdate('TASK_PUSHED');

      // Immediate background verification pull
      setTimeout(() => {
        this.pullFromCloud(true);
      }, 300);

      return true;
    } catch (e) {
      console.warn("Background cloud task sync notice - enqueuing retry:", e);
      this.queuePending({ action: 'SYNC_TASK', payload: task });
      this._setStatus('CONNECTED');
      return false;
    }
  },

  /**
   * Delete a single task from Google Sheets in background
   */
  async deleteTask(taskId, month) {
    const url = this.getWebAppUrl();
    if (!url || !taskId) return false;

    try {
      this._setStatus('SYNCING');
      await fetch(url, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          action: 'DELETE_TASK',
          payload: { task_id: taskId, month: month }
        })
      });
      this.lastSyncTime = new Date().toISOString();
      localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
      this._setStatus('CONNECTED');
      this._broadcastUpdate('TASK_DELETED');

      setTimeout(() => {
        this.pullFromCloud(true);
      }, 300);

      return true;
    } catch (e) {
      console.warn("Cloud delete notice - enqueuing retry:", e);
      this.queuePending({ action: 'DELETE_TASK', payload: { task_id: taskId, month: month } });
      this._setStatus('CONNECTED');
      return false;
    }
  },

  /**
   * Pull all tasks and cost savings from Google Sheets
   */
  async pullFromCloud(silent = false) {
    const url = this.getWebAppUrl();
    if (!url) return false;

    try {
      this.isSyncing = true;
      this._setStatus('SYNCING');

      const endpoint = url + (url.includes('?') ? '&' : '?') + 'action=GET_ALL&_t=' + Date.now();
      const res = await fetch(endpoint, { method: 'GET', mode: 'cors' });
      if (!res.ok) throw new Error("Fetch failed: " + res.status);

      const data = await res.json();
      if (data && data.status === 'OK') {
        let changed = false;

        // Merge workbooks into MonthWorkbookManager
        if (data.workbooks && window.appState && window.appState.workbookMgr) {
          changed = window.appState.workbookMgr.mergeFromCloud(data.workbooks) || changed;
        }

        // Merge Cost Savings if available
        if (Array.isArray(data.cost_savings) && data.cost_savings.length > 0 && typeof CostSavingTracker !== 'undefined') {
          // Sync cost savings if needed
        }

        this.lastSyncTime = new Date().toISOString();
        localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
        this._setStatus('CONNECTED');

        // Refresh views if data changed
        if (changed) {
          this._refreshActiveViews();
          this._broadcastUpdate('DATA_MERGED');
        }

        if (!silent && typeof HELPERS !== 'undefined' && HELPERS.showToast) {
          HELPERS.showToast("Cloud sync complete: All tasks up-to-date.", "success");
        }
        return true;
      }
    } catch (err) {
      console.warn("Pull from cloud notice:", err);
      // Stay connected so next cycle retries cleanly
      this._setStatus('CONNECTED');
      if (!silent && typeof HELPERS !== 'undefined' && HELPERS.showToast) {
        HELPERS.showToast("Cloud sync notice: " + err.message, "info");
      }
      return false;
    } finally {
      this.isSyncing = false;
      this._notifySubscribers();
    }
  },

  /**
   * Push all current local data to Google Sheet
   */
  async pushAllLocalData() {
    const url = this.getWebAppUrl();
    if (!url) throw new Error("Please configure Google Apps Script Web App URL first.");

    if (!window.appState || !window.appState.workbookMgr) {
      throw new Error("System state not initialized.");
    }

    this.isSyncing = true;
    this._setStatus('SYNCING');

    try {
      const workbooks = window.appState.workbookMgr.workbooks || {};
      let costSavings = [];
      if (typeof CostSavingTracker !== 'undefined' && CostSavingTracker.getAllRecords) {
        costSavings = CostSavingTracker.getAllRecords();
      }

      const res = await fetch(url, {
        method: 'POST',
        mode: 'cors',
        headers: { 'Content-Type': 'text/plain;charset=utf-8' },
        body: JSON.stringify({
          action: 'BULK_PUSH',
          payload: {
            workbooks: workbooks,
            cost_savings: costSavings
          }
        })
      });

      if (!res.ok) throw new Error("Upload failed: " + res.status);
      const data = await res.json();
      if (data.status === 'OK') {
        this.lastSyncTime = new Date().toISOString();
        localStorage.setItem(this.STORAGE_KEY_LAST_SYNC, this.lastSyncTime);
        this._setStatus('CONNECTED');
        this._broadcastUpdate('BULK_PUSHED');
        return data;
      } else {
        throw new Error(data.message || "Bulk push error.");
      }
    } finally {
      this.isSyncing = false;
      this._notifySubscribers();
    }
  },

  _setStatus(s) {
    this.status = s;
    this._notifySubscribers();
  },

  _refreshActiveViews() {
    try {
      const activeEl = document.activeElement;
      const isUserTyping = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');

      if (window.appState && window.appState.activeTab === 'monthly-input' && window.appState.monthlyInputView) {
        if (!isUserTyping) {
          window.appState.monthlyInputView.render();
        } else {
          // Re-render safely when user finishes typing
          activeEl.addEventListener('blur', () => {
            if (window.appState && window.appState.activeTab === 'monthly-input') {
              window.appState.monthlyInputView.render();
            }
          }, { once: true });
        }
      }

      if (window.appState && window.appState.activeTab === 'projects' && typeof ProjectsView !== 'undefined') {
        if (!isUserTyping) {
          ProjectsView.render();
        }
      }

      if (window.appState && window.appState.activeTab === 'dashboard' && window.appState.dashboardView) {
        window.appState.dashboardView.render();
      }
    } catch (e) {
      console.warn("View refresh notice:", e);
    }
  },

  _updateNavbarBadge() {
    const badge = document.getElementById('navbar-cloud-sync-badge');
    if (!badge) return;

    if (this.status === 'CONNECTED') {
      badge.innerHTML = `
        <button onclick="GoogleSheetsSync.pullFromCloud(false)" title="Google Sheets Connected & Auto-syncing every 5s. Click to sync now." 
                class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Live Sync (5s)</span>
        </button>
      `;
    } else if (this.status === 'SYNCING') {
      badge.innerHTML = `
        <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20">
          <span class="inline-block w-2.5 h-2.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></span>
          <span>Syncing...</span>
        </div>
      `;
    } else if (this.status === 'ERROR') {
      badge.innerHTML = `
        <button onclick="GoogleSheetsSync.pullFromCloud(false)" title="Sync warning. Click to retry." 
                class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20">
          <span class="w-2 h-2 rounded-full bg-rose-400"></span>
          <span>Sync Retry</span>
        </button>
      `;
    } else {
      badge.innerHTML = `
        <button onclick="if(window.appState) window.appState.switchTab('settings')" title="Click to connect Google Sheets" 
                class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700 hover:text-white transition-colors">
          <span class="w-2 h-2 rounded-full bg-slate-500"></span>
          <span>Offline Mode</span>
        </button>
      `;
    }
  }
};

if (typeof window !== 'undefined') {
  window.GoogleSheetsSync = GoogleSheetsSync;
}
if (typeof module !== 'undefined' && module.exports) {
  module.exports = GoogleSheetsSync;
}