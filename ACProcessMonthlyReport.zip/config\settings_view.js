/**
 * Process Development Monthly Report Automation System
 * Module: Settings View
 * Manages Gemini API Key, Google Workspace, and System Preferences
 * WALTON Hi-Tech Industries PLC
 */

const SettingsView = {
  render(containerId = 'settings-view-container') {
    const container = document.getElementById(containerId);
    if (!container) return;

    const currentKey = HELPERS.storage.get(APP_CONFIG.AI.STORAGE_KEY_API_KEY, "");

    container.innerHTML = `
      <div class="space-y-6 max-w-4xl">
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
          <span class="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            SYSTEM SETTINGS & INTEGRATIONS
          </span>
          <h2 class="text-2xl font-black text-white mt-1">Application Configuration</h2>
          <p class="text-xs text-slate-400 mt-0.5">Manage Gemini 3.8 Flash API key, cloud endpoints, and local storage cache.</p>
        </div>

        <!-- Gemini API Key Configuration Card -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              ⚡
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Google Gemini 3.8 Flash API Integration</h3>
              <p class="text-xs text-slate-400">Used for technical summary rewriting and zero-fabrication impact synthesis.</p>
            </div>
          </div>

          <div>
            <label class="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Gemini API Key</label>
            <div class="flex items-center gap-3">
              <input type="password" id="settings-gemini-key" value="${HELPERS.escapeHtml(currentKey)}" placeholder="AIzaSy..." 
                     class="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono" />
              <button onclick="SettingsView.saveGeminiKey()" class="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-xs font-bold text-white shadow">
                Save Key
              </button>
            </div>
            <p class="text-[11px] text-slate-500 mt-1">
              If left blank, the system automatically uses deterministic rule-based local transformation with 100% offline capability.
            </p>
          </div>
        </div>

        <!-- Storage & Cache Controls -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h3 class="text-sm font-bold text-white">Cache &amp; Local Persistence</h3>
          <p class="text-xs text-slate-400">Clear cached AI breakdowns or reload original seed data.</p>
          <div class="flex flex-wrap gap-3">
            <button onclick="SettingsView.clearAICache()" class="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 border border-slate-700">
              🧹 Clear AI Response Cache
            </button>
            <button onclick="SettingsView.resetWorkbooks()" class="px-4 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-xs font-semibold text-rose-400 border border-rose-500/30">
              🔄 Reset Month Workbooks to Defaults
            </button>
          </div>
        </div>
      </div>
    `;
  },

  saveGeminiKey() {
    const key = document.getElementById('settings-gemini-key').value.trim();
    HELPERS.storage.set(APP_CONFIG.AI.STORAGE_KEY_API_KEY, key);
    alert(key ? "Gemini API Key saved successfully!" : "Gemini API Key removed. Local rule fallback active.");
  },

  clearAICache() {
    AICacheManager.clear();
    alert("AI Cache cleared successfully.");
  },

  resetWorkbooks() {
    if (confirm("Reset all monthly workbooks back to original seed data? This will overwrite local edits.")) {
      localStorage.removeItem("walton_pd_month_workbooks_v1");
      localStorage.removeItem("walton_pd_month_workbooks_v2");
      localStorage.removeItem("walton_pd_ai_breakdown_v1");
      if (window.appState && window.appState.workbookMgr) {
        window.appState.workbookMgr.init();
      }
      alert("Workbooks reset. Reloading view.");
      window.location.reload();
    }
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SettingsView;
} else if (typeof window !== 'undefined') {
  window.SettingsView = SettingsView;
}
