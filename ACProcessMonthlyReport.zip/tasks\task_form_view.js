/**
 * Process Development Monthly Report Automation System
 * Module: Task Form View (Ultra-Simple Engineer Entry)
 * Principle: ENGINEER ENTERS ONLY TASK NAME + Selects Engineer from Master Data
 * WALTON Hi-Tech Industries PLC
 */

const TaskFormView = {
  activeTaskId: null,

  renderModalContainer() {
    let container = document.getElementById('task-form-modal-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'task-form-modal-container';
      document.body.appendChild(container);
    }
    return container;
  },

  /**
   * Opens the simple engineer entry form
   */
  open(taskId = null, defaultMonth = "SEP-2026") {
    this.activeTaskId = taskId;
    const container = this.renderModalContainer();

    const workbookMgr = window.appState && window.appState.workbookMgr
      ? window.appState.workbookMgr
      : new MonthWorkbookManager();

    const currentMonth = workbookMgr.normalizeMonth(defaultMonth);
    let task = null;

    if (taskId) {
      const tasks = workbookMgr.getTasksForMonth(currentMonth);
      task = tasks.find(t => t.task_id === taskId);
    }

    const isEdit = Boolean(task);
    const title = isEdit ? `Edit Task (${task.task_id})` : "New Engineering Task Entry";

    // Build Engineer Dropdown Options
    const engineers = typeof MASTER_LISTS !== 'undefined' ? MASTER_LISTS.ENGINEERS : [
      { name: "Sazzad", id: "50463" }, { name: "Rafi", id: "45127" }, { name: "Faiyaz", id: "54634" },
      { name: "Abdullah", id: "58102" }, { name: "Emon", id: "58279" }, { name: "Hashmi", id: "56880" }
    ];

    const currentEng = task ? task.engineer : (engineers[0] ? engineers[0].name : "Sazzad");
    const engineerOptions = engineers.map(e => 
      `<option value="${e.name}" ${currentEng.startsWith(e.name) ? 'selected' : ''}>${e.name} ${e.id ? `(${e.id})` : ''}</option>`
    ).join('');

    const availableMonths = workbookMgr.getAllMonths();

    container.innerHTML = `
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
        <div class="relative w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl p-6 sm:p-8 text-slate-800">
          
          <!-- Header -->
          <div class="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <span class="text-xs font-mono uppercase tracking-wider text-red-600 font-bold">Fast Engineer Entry</span>
              <h2 class="text-xl font-extrabold text-slate-800 mt-0.5">${title}</h2>
              <p class="text-xs text-slate-400 mt-0.5">Enter only the Task Name. AI automatically derives breakdown & slides.</p>
            </div>
            <button onclick="TaskFormView.close()" class="text-slate-400 hover:text-slate-700 p-2 rounded-lg hover:bg-slate-100 transition">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
          </div>

          <!-- Form Body -->
          <form id="simple-task-entry-form" onsubmit="TaskFormView.handleSubmit(event)" class="mt-5 space-y-4">
            <input type="hidden" id="entry-task-id" value="${task ? task.task_id : ''}">

            <div class="grid grid-cols-2 gap-4">
              <!-- Month -->
              <div>
                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Reporting Month</label>
                <select id="entry-task-month" required class="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 focus:outline-none focus:border-red-400 focus:ring-1 focus:ring-red-100 font-mono font-bold shadow-sm">
                  ${availableMonths.map(m => `<option value="${m}" ${currentMonth === m ? 'selected' : ''}>${m}</option>`).join('')}
                </select>
              </div>

              <!-- Engineer Dropdown from Master Data -->
              <div>
                <label class="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">Concern Engineer *</label>
                <select id="entry-task-engineer" required class="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 focus:outline-none focus:border-red-400 focus:ring-1 focus:ring-red-100 font-medium shadow-sm">
                  ${engineerOptions}
                </select>
              </div>
            </div>

            <!-- Task Name (The only mandatory engineering entry) -->
            <div>
              <label class="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                Task Name *
              </label>
              <input type="text" id="entry-task-name" required value="${task ? HELPERS.escapeHtml(task.task_name) : ''}" 
                     placeholder="e.g. Compressor Jacket Foil Cutting System Development" 
                     class="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-800 focus:outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100 font-medium shadow-sm" />
              <p class="text-[11px] text-slate-400 mt-1">
                AI will generate the short title, description, impact points, category, and report slide automatically upon save.
              </p>
            </div>

            <!-- Actions -->
            <div class="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
              <button type="button" onclick="TaskFormView.close()" class="px-5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-500 hover:bg-slate-50 transition shadow-sm">
                Cancel
              </button>
              <button type="submit" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-sm font-bold text-white shadow-lg shadow-red-200/50 transition">
                Save &amp; Generate Slide
              </button>
            </div>

          </form>

        </div>
      </div>
    `;
  },

  async handleSubmit(event) {
    event.preventDefault();
    const taskId = document.getElementById('entry-task-id').value.trim();
    const month = document.getElementById('entry-task-month').value.trim();
    const engineer = document.getElementById('entry-task-engineer').value.trim();
    const taskName = document.getElementById('entry-task-name').value.trim();

    if (!taskName) {
      alert("Please enter a Task Name.");
      return;
    }

    const workbookMgr = window.appState && window.appState.workbookMgr
      ? window.appState.workbookMgr
      : new MonthWorkbookManager();

    try {
      if (taskId) {
        workbookMgr.updateTask(month, taskId, { task_name: taskName, engineer: engineer });
      } else {
        workbookMgr.addTask(month, engineer, taskName, "YES");
      }

      // Automatically run synchronization for instant readiness
      if (window.appState && window.appState.syncEngine) {
        await window.appState.syncEngine.syncMonth(month);
      }

      this.close();

      // Refresh current view
      if (window.App && window.App.refreshCurrentTab) {
        window.App.refreshCurrentTab();
      } else if (typeof MonthlyInputView !== 'undefined') {
        MonthlyInputView.render();
      }
    } catch (e) {
      alert("Error saving task: " + e.message);
    }
  },

  close() {
    const container = document.getElementById('task-form-modal-container');
    if (container) container.innerHTML = '';
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = TaskFormView;
} else if (typeof window !== 'undefined') {
  window.TaskFormView = TaskFormView;
}
