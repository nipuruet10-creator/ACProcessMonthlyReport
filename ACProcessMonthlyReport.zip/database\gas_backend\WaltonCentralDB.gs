/**
 * @OnlyCurrentDoc
 * ==============================================================================
 * Process Development Monthly Report Automation System
 * Central Cloud Database Backend for Google Sheets
 * Organization: WALTON Hi-Tech Industries PLC
 * Department: Process Development (AC)
 * ==============================================================================
 * 
 * SETUP INSTRUCTIONS:
 * 1. Open Google Sheets (https://sheets.new)
 * 2. Rename spreadsheet to: "Walton AC Process Monthly Report DB"
 * 3. Go to: Extensions > Apps Script
 * 4. Delete any code in the editor and PASTE THIS ENTIRE SCRIPT.
 * 5. Click "Save" (disk icon).
 * 6. Click "Deploy" (blue button at top right) > "New deployment".
 * 7. Select type: "Web app" (click gear icon next to 'Select type' if needed).
 * 8. Set Configuration:
 *    - Description: "Walton AC Process Sync API"
 *    - Execute as: "Me (your email)"
 *    - Who has access: "Anyone" (Required so your web app can sync without login popups)
 * 9. Click "Deploy", authorize permissions when prompted.
 * 10. Copy the "Web app URL" and paste it into the Settings page of your application!
 * ==============================================================================
 */

const DB_CONFIG = {
  SHEET_TASKS: 'TASKS',
  SHEET_COST_SAVINGS: 'COST_SAVINGS',
  SHEET_META: 'SYSTEM_INFO',
  TASK_HEADERS: [
    'task_id', 'month', 'task_name', 'task_details', 'category',
    'points', 'supervisor', 'assignee', 'engineer', 'start_date',
    'end_date', 'status', 'include_in_report', 'photo_1', 'photo_2',
    'ai_report_title', 'ai_report_description', 'ai_report_impact',
    'remarks', 'last_updated'
  ],
  COST_HEADERS: [
    'year', 'month_code', 'target_bdt', 'achieved_bdt', 'project_count', 'remarks', 'last_updated'
  ]
};

/**
 * Handle HTTP GET Requests
 */
function doGet(e) {
  try {
    const params = e ? e.parameter : {};
    const action = params.action || 'PING';
    let result = {};

    if (action === 'PING' || action === 'health') {
      result = {
        status: 'OK',
        system: 'Walton AC Process Report Central DB',
        version: '2.0.0',
        timestamp: new Date().toISOString()
      };
    } else if (action === 'GET_ALL') {
      result = {
        status: 'OK',
        workbooks: getAllWorkbooksGrouped(),
        cost_savings: getAllCostSavings(),
        timestamp: new Date().toISOString()
      };
    } else if (action === 'GET_MONTH') {
      const month = params.month || 'SEP-2026';
      result = {
        status: 'OK',
        month: month,
        tasks: getTasksForMonth(month),
        timestamp: new Date().toISOString()
      };
    } else {
      result = { status: 'ERROR', message: 'Unknown GET action: ' + action };
    }

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'ERROR',
      message: err.message,
      stack: err.stack
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Handle HTTP POST Requests
 */
function doPost(e) {
  try {
    let requestData = {};
    if (e && e.postData && e.postData.contents) {
      try {
        requestData = JSON.parse(e.postData.contents);
      } catch (parseErr) {
        requestData = {};
      }
    }

    const action = requestData.action || '';
    const payload = requestData.payload || {};
    let result = {};

    if (action === 'SYNC_TASK') {
      result = syncSingleTask(payload);
    } else if (action === 'DELETE_TASK') {
      result = deleteSingleTask(payload.task_id, payload.month);
    } else if (action === 'BULK_PUSH') {
      result = bulkPushAllData(payload);
    } else if (action === 'SYNC_COST_SAVINGS') {
      result = syncCostSavingsTable(payload);
    } else {
      result = { status: 'ERROR', message: 'Unsupported POST action: ' + action };
    }

    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      status: 'ERROR',
      message: err.message,
      stack: err.stack
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// -----------------------------------------------------------------------------
// Sheet Initializers & Helpers
// -----------------------------------------------------------------------------

function getSpreadsheet() {
  return SpreadsheetApp.getActiveSpreadsheet();
}

function getOrCreateSheet(sheetName, headers, headerColor) {
  const ss = getSpreadsheet();
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    sheet.appendRow(headers);
    const range = sheet.getRange(1, 1, 1, headers.length);
    range.setFontWeight('bold')
      .setBackground(headerColor || '#1E293B')
      .setFontColor('#FFFFFF')
      .setHorizontalAlignment('center');
    sheet.setFrozenRows(1);
    sheet.setRowHeight(1, 32);
  }
  return sheet;
}

function getTasksSheet() {
  return getOrCreateSheet(DB_CONFIG.SHEET_TASKS, DB_CONFIG.TASK_HEADERS, '#0F172A');
}

function getCostSheet() {
  return getOrCreateSheet(DB_CONFIG.SHEET_COST_SAVINGS, DB_CONFIG.COST_HEADERS, '#1E3A8A');
}

// -----------------------------------------------------------------------------
// Database Operations
// -----------------------------------------------------------------------------

/**
 * Retrieve all tasks grouped by month { "JAN-2026": [...], "SEP-2026": [...] }
 */
function getAllWorkbooksGrouped() {
  const sheet = getTasksSheet();
  const data = sheet.getDataRange().getValues();
  if (data.length <= 1) return {};

  const headers = data[0];
  const workbooks = {};

  for (let r = 1; r < data.length; r++) {
    const row = data[r];
    const task = {};
    headers.forEach((h, col) => {
      task[h] = row[col];
    });

    let rawMonth = String(task.month || '').trim();
    let upper = rawMonth.toUpperCase();
    const monthMap = {
      "JAN": "JAN", "FEB": "FEB", "MAR": "MAR", "APR": "APR", "MAY": "MAY", "JUN": "JUN",
      "JUL": "JUL", "AUG": "AUG", "SEP": "SEP", "OCT": "OCT", "NOV": "NOV", "DEC": "DEC",
      "JANUARY": "JAN", "FEBRUARY": "FEB", "MARCH": "MAR", "APRIL": "APR", "JUNE": "JUN",
      "JULY": "JUL", "AUGUST": "AUG", "SEPTEMBER": "SEP", "OCTOBER": "OCT", "NOVEMBER": "NOV", "DECEMBER": "DEC"
    };
    let mMatch = upper.match(/\b(JANUARY|FEBRUARY|MARCH|APRIL|MAY|JUNE|JULY|AUGUST|SEPTEMBER|OCTOBER|NOVEMBER|DECEMBER|JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)\b/);
    let yMatch = upper.match(/\b(202\d|203\d)\b/);
    let m = (mMatch && yMatch) ? (monthMap[mMatch[1]] + '-' + yMatch[1]) : (upper || 'SEP-2026');
    task.month = m;

    if (!workbooks[m]) {
      workbooks[m] = [];
    }
    workbooks[m].push(task);
  }

  return workbooks;
}

/**
 * Retrieve tasks for a specific month (optimized for sub-second responses)
 */
function getTasksForMonth(month) {
  const target = month ? month.toUpperCase().trim() : 'SEP-2026';
  const targetPrefix = target.split('-')[0]; // e.g. "SEP"
  const targetYear = target.split('-')[1] || '2026'; // e.g. "2026"

  const sheet = getTasksSheet();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return [];

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const monthColIdx = headers.indexOf('month');
  if (monthColIdx === -1) return [];

  const allValues = sheet.getRange(2, 1, lastRow - 1, headers.length).getValues();
  const tasks = [];

  for (let i = 0; i < allValues.length; i++) {
    const row = allValues[i];
    const rawMonth = String(row[monthColIdx] || '').toUpperCase();
    
    // Match exact month code or Date object string
    const matchesTarget = (rawMonth === target) ||
      (rawMonth.includes(targetPrefix) && rawMonth.includes(targetYear)) ||
      (target === 'SEP-2026' && (rawMonth.includes('SEP') || rawMonth.includes('SEPTEMBER')));

    if (matchesTarget) {
      const task = {};
      headers.forEach((h, col) => {
        task[h] = row[col];
      });
      task.month = target;
      tasks.push(task);
    }
  }

  return tasks;
}

/**
 * Insert or update a single task in the TASKS sheet
 */
function syncSingleTask(task) {
  if (!task || !task.task_id) {
    return { status: 'ERROR', message: 'Task ID is required' };
  }

  const sheet = getTasksSheet();
  const data = sheet.getDataRange().getValues();
  const headers = DB_CONFIG.TASK_HEADERS;
  const taskIdCol = 0; // task_id is column 0

  let foundRowIndex = -1;
  for (let r = 1; r < data.length; r++) {
    if (String(data[r][taskIdCol]).trim() === String(task.task_id).trim()) {
      foundRowIndex = r + 1; // 1-based index
      break;
    }
  }

  task.last_updated = new Date().toISOString();
  const rowData = headers.map(h => {
    const val = task[h];
    return val !== undefined && val !== null ? val : '';
  });

  if (foundRowIndex > 0) {
    sheet.getRange(foundRowIndex, 1, 1, headers.length).setValues([rowData]);
    return { status: 'OK', action: 'UPDATED', task_id: task.task_id };
  } else {
    sheet.appendRow(rowData);
    return { status: 'OK', action: 'INSERTED', task_id: task.task_id };
  }
}

/**
 * Delete a single task by taskId
 */
function deleteSingleTask(taskId, month) {
  if (!taskId) return { status: 'ERROR', message: 'Task ID required' };

  const sheet = getTasksSheet();
  const data = sheet.getDataRange().getValues();
  const taskIdCol = 0;

  for (let r = 1; r < data.length; r++) {
    if (String(data[r][taskIdCol]).trim() === String(taskId).trim()) {
      sheet.deleteRow(r + 1);
      return { status: 'OK', action: 'DELETED', task_id: taskId };
    }
  }

  return { status: 'NOT_FOUND', task_id: taskId };
}

/**
 * Bulk push all local workbooks and cost savings from frontend into Google Sheet
 */
function bulkPushAllData(payload) {
  const workbooks = payload.workbooks || {};
  const costSavings = payload.cost_savings || [];

  const taskSheet = getTasksSheet();
  // Clear existing task data rows (keep headers)
  if (taskSheet.getLastRow() > 1) {
    taskSheet.deleteRows(2, taskSheet.getLastRow() - 1);
  }

  const headers = DB_CONFIG.TASK_HEADERS;
  const taskRows = [];

  const months = Object.keys(workbooks);
  months.forEach(m => {
    const list = workbooks[m] || [];
    list.forEach(t => {
      const row = headers.map(h => {
        const val = t[h];
        return val !== undefined && val !== null ? val : '';
      });
      taskRows.push(row);
    });
  });

  if (taskRows.length > 0) {
    taskSheet.getRange(2, 1, taskRows.length, headers.length).setValues(taskRows);
    taskSheet.getRange(2, 2, taskRows.length, 1).setNumberFormat('@');
  }

  // Update Cost Savings
  if (Array.isArray(costSavings) && costSavings.length > 0) {
    syncCostSavingsTable(costSavings);
  }

  return {
    status: 'OK',
    action: 'BULK_SAVED',
    total_tasks: taskRows.length,
    months_count: months.length,
    timestamp: new Date().toISOString()
  };
}

/**
 * Retrieve all Cost Savings rows
 */
function getAllCostSavings() {
  const sheet = getCostSheet();
  const data = sheet.getDataRange().getValues();
  if (data.length <= 1) return [];

  const headers = data[0];
  const list = [];
  for (let r = 1; r < data.length; r++) {
    const row = data[r];
    const item = {};
    headers.forEach((h, col) => {
      item[h] = row[col];
    });
    list.push(item);
  }
  return list;
}

/**
 * Sync Cost Savings Table
 */
function syncCostSavingsTable(costList) {
  if (!Array.isArray(costList)) return { status: 'ERROR', message: 'Array expected' };

  const sheet = getCostSheet();
  if (sheet.getLastRow() > 1) {
    sheet.deleteRows(2, sheet.getLastRow() - 1);
  }

  const headers = DB_CONFIG.COST_HEADERS;
  const rows = costList.map(item => {
    return headers.map(h => item[h] !== undefined && item[h] !== null ? item[h] : '');
  });

  if (rows.length > 0) {
    sheet.getRange(2, 1, rows.length, headers.length).setValues(rows);
  }

  return { status: 'OK', count: rows.length };
}
